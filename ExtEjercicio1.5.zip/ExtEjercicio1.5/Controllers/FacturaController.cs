﻿using Ejercicio1._5.Dominio;
using Ejercicio1._5.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ExtEjercicio1._5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : ControllerBase
    {
        private FacturaServicescs _facturaServicescs;

        // GET: api/<FacturaController>
        [HttpGet("/facturas")]
        public IActionResult GetFacturas()
        {
            List<Factura> facturas = null;
            try
            {
                _facturaServicescs = new FacturaServicescs();
                facturas = _facturaServicescs.GetFacturas();
                return Ok(facturas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error Interno");
            }

        }
        // POST api/<FacturaController>
        [HttpPost]
        public IActionResult PostFactura(Factura factura)
        {
            try
            {
                _facturaServicescs = new FacturaServicescs();
                var result = _facturaServicescs.SaveFactura(factura);
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(400, "Error al guardar la factura");
            }
        }
    }
}
