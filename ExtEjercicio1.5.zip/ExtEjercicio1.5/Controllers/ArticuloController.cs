﻿using Ejercicio1._5.Dominio;
using Ejercicio1._5.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ExtEjercicio1._5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticuloController : ControllerBase
    {
        private ArticuloServices _articuloServices;
        public ArticuloController()
        {
            _articuloServices= new ArticuloServices();
        }

        [HttpGet("/articulos")]
        public IActionResult GetArticulos()
        {
            List<Articulo> articulos = null;
            try
            {
                articulos = _articuloServices.GetProducts();
                return Ok(articulos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error Interno");
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetArticulo(int id)
        {
            Articulo a = null;
            try
            {
                a = _articuloServices.GetProductById(id);
                return Ok(a);
            }
            catch (Exception)
            {
                return StatusCode(400, "Identificador de Articulo incorrecto");
            }
        }

        // POST api/<ArticuloController>
        [HttpPost("/articulo")]
        public IActionResult PostArticulo(Articulo articulo)
        {
            try
            {
                var result = _articuloServices.SaveProduct(articulo);
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(400, "Error al guardar el articulo");
            }
        }

        // DELETE api/<ArticuloController>/5
        [HttpDelete("{id}")]
        public IActionResult DeleteArticulo(int id)
        {
            try
            {
                _articuloServices.DeleteProduct(id);
                return Ok("Articulo eliminado");
            }
            catch (Exception)
            {

                return StatusCode(400, "Identificador de Articulo incorrecto");
            }
        }
    }
}
