﻿namespace Envios.Models.DTOS
{
    public class DetalleEnvioDTO
    {
    public int Id { get; set; }
        public int Cantidad { get; set; }
        public string Comentario { get; set; }
    }
}
